# SADEE x DIMA License System
Two separate Android apps: userApp and adminApp.

The included build is a starter: admin generates keys locally and user validates the key format/demo activation locally. For real online licenses, connect both apps to a secure HTTPS/Firebase/Supabase backend. Server-side expiry/revocation is required; never ship a private service-account key inside an APK.

Key format: SADEEXDIMA-4786-AB29-6569
Plans: 1, 3, 7, 14, 30 days, Lifetime.
Build:
gradle :userApp:assembleDebug
gradle :adminApp:assembleDebug
