package com.sadee.dimaoptimizer;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {

    private LinearLayout content;
    private final Handler handler = new Handler();
    private TextView model, androidVersion, ram, storage, battery, temperature, power;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.rgb(245, 242, 255));
        t.setTextSize(size);
        t.setPadding(dp(4), dp(4), dp(4), dp(4));
        return t;
    }

    private TextView muted(String value) {
        TextView t = text(value, 12);
        t.setTextColor(Color.rgb(170, 165, 184));
        return t;
    }

    private TextView card(String value) {
        TextView t = text(value, 16);
        t.setBackgroundResource(R.drawable.bg_card);
        t.setPadding(dp(16), dp(15), dp(16), dp(15));
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(6), 0, dp(6));
        t.setLayoutParams(p);
        return t;
    }

    private Button button(String value, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setMinHeight(dp(54));
        b.setBackgroundResource(primary
                ? R.drawable.button_primary
                : R.drawable.button_outline);

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(-1, dp(56));
        p.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(p);
        return b;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        getWindow().setStatusBarColor(Color.rgb(11, 11, 16));
        getWindow().setNavigationBarColor(Color.rgb(11, 11, 16));

        buildLayout();
        showHome();
        startLiveUpdates();
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(8));
        root.setBackgroundColor(Color.rgb(11, 11, 16));

        TextView title = text("SADEE × DIMA", 26);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView sub = muted("OPTIMIZER  •  ANDROID GAMING UTILITY");
        sub.setTextColor(Color.rgb(156, 108, 255));
        root.addView(sub);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);

        root.addView(scroll, new LinearLayout.LayoutParams(
                -1, 0, 1));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(0, dp(4), 0, 0);

        Button home = button("⌂  HOME", false);
        Button optimize = button("⚡  OPTIMIZE", false);
        Button settings = button("⚙  SETTINGS", false);

        home.setTextSize(11);
        optimize.setTextSize(11);
        settings.setTextSize(11);

        home.setOnClickListener(v -> showHome());
        optimize.setOnClickListener(v -> showOptimize());
        settings.setOnClickListener(v -> showSettings());

        navigation.addView(home, new LinearLayout.LayoutParams(
                0, dp(52), 1));
        navigation.addView(optimize, new LinearLayout.LayoutParams(
                0, dp(52), 1));
        navigation.addView(settings, new LinearLayout.LayoutParams(
                0, dp(52), 1));

        root.addView(navigation);

        setContentView(root);
    }

    private void clear() {
        content.removeAllViews();
    }

    private void showHome() {
        clear();

        content.addView(text("DEVICE DASHBOARD", 22));
        content.addView(muted("LIVE DEVICE INFORMATION"));

        model = card("📱  PHONE MODEL\nLoading...");
        androidVersion = card("🤖  ANDROID\nLoading...");
        ram = card("🧠  RAM\nLoading...");
        storage = card("💾  STORAGE\nLoading...");
        battery = card("🔋  BATTERY\nLoading...");
        temperature = card("🌡️  TEMPERATURE\nLoading...");
        power = card("⚡  POWER\nLoading...");

        content.addView(model);
        content.addView(androidVersion);
        content.addView(ram);
        content.addView(storage);
        content.addView(battery);
        content.addView(temperature);
        content.addView(power);

        Button game = button("🎮  LAUNCH FREE FIRE", true);
        game.setOnClickListener(v -> launchFreeFire());
        content.addView(game);

        TextView live = muted("● LIVE • updates automatically");
        live.setTextColor(Color.rgb(73, 226, 138));
        content.addView(live);
    }

    private void showOptimize() {
        clear();

        content.addView(text("OPTIMIZER", 24));
        content.addView(muted("SAFE ANDROID-SIDE OPTIMIZATION"));

        content.addView(card(
                "⚡  READY TO OPTIMIZE\n\n" +
                "Refreshes live device information and provides " +
                "Android-supported settings shortcuts."));

        Button optimize = button("⚡  OPTIMIZE NOW", true);
        TextView result = card("Optimization status: READY");

        content.addView(optimize);
        content.addView(result);

        optimize.setOnClickListener(v -> {
            optimize.setEnabled(false);
            result.setText(
                    "⚡ OPTIMIZING...\n\n" +
                    "Refreshing RAM, storage and battery status..."
            );

            handler.postDelayed(() -> {
                updateLive();
                result.setText(
                        "✓ OPTIMIZATION COMPLETE\n\n" +
                        "Device information refreshed successfully."
                );
                optimize.setEnabled(true);
            }, 1200);
        });

        Button game = button("🎮  OPEN FREE FIRE", false);
        game.setOnClickListener(v -> launchFreeFire());
        content.addView(game);

        Button batterySettings =
                button("🔋  BATTERY SETTINGS", false);
        batterySettings.setOnClickListener(v ->
                openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        content.addView(batterySettings);
    }

    private void showSettings() {
        clear();

        content.addView(text("SETTINGS", 24));
        content.addView(muted("ANDROID SHORTCUTS"));

        Button display = button("📺  DISPLAY SETTINGS", false);
        display.setOnClickListener(v ->
                openSettings(Settings.ACTION_DISPLAY_SETTINGS));
        content.addView(display);

        Button batterySettings =
                button("🔋  BATTERY SETTINGS", false);
        batterySettings.setOnClickListener(v ->
                openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        content.addView(batterySettings);

        Button appInfo = button("ℹ️  APP INFO", false);
        appInfo.setOnClickListener(v ->
                openSettings(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
        content.addView(appInfo);

        Button usage = button("📊  USAGE ACCESS", false);
        usage.setOnClickListener(v ->
                openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        content.addView(usage);

        content.addView(card(
                "SADEE × DIMA OPTIMIZER\n\n" +
                "Version 1.0\n\n" +
                "Android 15 compatible gaming utility."
        ));
    }

    private void openSettings(String action) {
        openSettings(action, null);
    }

    private void openSettings(String action, Uri data) {
        try {
            Intent intent = new Intent(action);
            if (data != null) {
                intent.setData(data);
            }
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void launchFreeFire() {
        String[] packages = {
                "com.dts.freefireth",
                "com.dts.freefiremax"
        };

        for (String packageName : packages) {
            Intent launch =
                    getPackageManager().getLaunchIntentForPackage(packageName);

            if (launch != null) {
                startActivity(launch);
                return;
            }
        }

        Toast.makeText(
                this,
                "Free Fire is not installed.",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void startLiveUpdates() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                updateLive();
                handler.postDelayed(this, 1000);
            }
        });
    }

    private void updateLive() {
        if (model == null) return;

        model.setText(
                "📱  PHONE MODEL\n" +
                Build.MANUFACTURER + " " + Build.MODEL
        );

        androidVersion.setText(
                "🤖  ANDROID\n" +
                Build.VERSION.RELEASE +
                "  •  API " + Build.VERSION.SDK_INT
        );

        ActivityManager manager =
                (ActivityManager) getSystemService(ACTIVITY_SERVICE);

        ActivityManager.MemoryInfo memory =
                new ActivityManager.MemoryInfo();

        manager.getMemoryInfo(memory);

        long totalRam = memory.totalMem;
        long freeRam = memory.availMem;
        long usedRam = totalRam - freeRam;

        ram.setText(
                "🧠  RAM\n" +
                formatBytes(usedRam) + " used  /  " +
                formatBytes(totalRam) + " total\n" +
                formatBytes(freeRam) + " available"
        );

        File data = Environment.getDataDirectory();

        long totalStorage = data.getTotalSpace();
        long freeStorage = data.getFreeSpace();
        long usedStorage = totalStorage - freeStorage;

        storage.setText(
                "💾  STORAGE\n" +
                formatBytes(usedStorage) + " used  /  " +
                formatBytes(totalStorage) + " total\n" +
                formatBytes(freeStorage) + " free"
        );

        IntentFilter filter =
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED);

        Intent batteryIntent =
                registerReceiver(null, filter);

        if (batteryIntent != null) {
            int level =
                    batteryIntent.getIntExtra("level", 0);

            int scale =
                    batteryIntent.getIntExtra("scale", 100);

            int percent =
                    (int) (level * 100f / scale);

            int status =
                    batteryIntent.getIntExtra("status", -1);

            float temp =
                    batteryIntent.getIntExtra(
                            "temperature", 0) / 10f;

            String charging;

            if (status == 2) {
                charging = "Charging";
            } else if (status == 5) {
                charging = "Full";
            } else {
                charging = "Not charging";
            }

            battery.setText(
                    "🔋  BATTERY\n" +
                    percent + "%"
            );

            temperature.setText(
                    "🌡️  TEMPERATURE\n" +
                    String.format(
                            Locale.US,
                            "%.1f°C",
                            temp)
            );

            power.setText(
                    "⚡  POWER\n" +
                    charging
            );
        }
    }

    private String formatBytes(long bytes) {
        double value = bytes;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int index = 0;

        while (value >= 1024 &&
                index < units.length - 1) {
            value /= 1024;
            index++;
        }

        return String.format(
                Locale.US,
                "%.1f %s",
                value,
                units[index]
        );
    }
}
