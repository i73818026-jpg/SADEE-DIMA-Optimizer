# SADEE × DIMA Optimizer

Android 15 compatible 3-page device dashboard / gaming utility.

## GitHub Actions

Push the repository contents so `settings.gradle` is in the repository root.

Then open **Actions → Build SADEE DIMA Optimizer APK → Run workflow**.

The generated debug APK is uploaded as the `SADEE-DIMA-Optimizer-APK` artifact.
