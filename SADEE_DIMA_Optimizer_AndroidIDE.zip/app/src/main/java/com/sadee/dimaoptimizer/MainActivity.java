package com.sadee.dimaoptimizer;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    TextView title, subtitle, model, androidV, ram, storage, battery, temp, charge, status;
    Handler handler = new Handler(Looper.getMainLooper());

    int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    TextView tv(String s, float size){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.rgb(245,242,255)); t.setTextSize(size);
        t.setFontFeatureSettings("kern"); t.setPadding(dp(2),dp(3),dp(2),dp(3)); return t;
    }
    Button btn(String text, boolean primary){
        Button b=new Button(this); b.setText(text); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setMinHeight(dp(54)); b.setPadding(dp(10),0,dp(10),0);
        b.setBackgroundResource(primary ? com.sadee.dimaoptimizer.R.drawable.button_primary : com.sadee.dimaoptimizer.R.drawable.button_outline);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(58)); p.setMargins(0,dp(7),0,dp(7)); b.setLayoutParams(p); return b;
    }
    TextView label(String s){ TextView t=tv(s,13); t.setTextColor(Color.rgb(170,165,184)); return t; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11,11,16)); getWindow().setNavigationBarColor(Color.rgb(11,11,16));
        buildShell(); showHome(); startLive();
    }

    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(11,11,16));
        root.setPadding(dp(18),dp(12),dp(18),dp(8)); setContentView(root);
        title=tv("SADEE × DIMA",26); title.setTypeface(null,1); root.addView(title);
        subtitle=tv("OPTIMIZER  •  ANDROID GAMING UTILITY",12); subtitle.setTextColor(Color.rgb(156,108,255)); root.addView(subtitle);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(0,dp(5),0,0);
        String[] ns={"⌂  HOME","⚡  OPTIMIZE","⚙  SETTINGS"};
        for(int i=0;i<3;i++){ final int x=i; Button n=btn(ns[i],false); n.setTextSize(12); n.setOnClickListener(v->{if(x==0)showHome();else if(x==1)showOptimize();else showSettings();}); nav.addView(n,new LinearLayout.LayoutParams(0,dp(54),1));}
        root.addView(nav);
    }

    TextView cardText(String text){
        TextView t=tv(text,16); t.setBackgroundResource(R.drawable.bg_card); t.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(7),0,dp(7)); t.setLayoutParams(p); return t;
    }

    void clear(){content.removeAllViews();}

    void showHome(){
        clear();
        content.addView(tv("DEVICE DASHBOARD",22));
        content.addView(label("LIVE DEVICE INFORMATION"));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        model=cardText("📱  PHONE MODEL\nLoading…"); grid.addView(model);
        androidV=cardText("🤖  ANDROID\nLoading…"); grid.addView(androidV);
        ram=cardText("🧠  RAM\nLoading…"); grid.addView(ram);
        storage=cardText("💾  STORAGE\nLoading…"); grid.addView(storage);
        battery=cardText("🔋  BATTERY\nLoading…"); grid.addView(battery);
        temp=cardText("🌡️  TEMPERATURE\nLoading…"); grid.addView(temp);
        charge=cardText("⚡  POWER\nLoading…"); grid.addView(charge);
        content.addView(grid);
        Button launch=btn("🎮  LAUNCH FREE FIRE",true);
        launch.setOnClickListener(v->launchGame()); content.addView(launch);
        status=tv("● LIVE • updating automatically",12); status.setTextColor(Color.rgb(73,226,138)); content.addView(status);
    }

    void showOptimize(){
        clear();
        content.addView(tv("OPTIMIZER",25));
        content.addView(label("SAFE ANDROID-SIDE OPTIMIZATION"));
        TextView info=cardText("⚡  READY TO OPTIMIZE\n\nThe optimizer refreshes live device information and opens Android's supported game/battery settings. It does not modify game files, memory packets, cheats, or anti-cheat systems.");
        content.addView(info);
        Button go=btn("⚡  OPTIMIZE NOW",true); content.addView(go);
        TextView result=cardText("Optimization status: Ready"); content.addView(result);
        go.setOnClickListener(v->{
            go.setEnabled(false); result.setText("⚡ Optimizing…\n\nRefreshing RAM, storage and battery status…");
            handler.postDelayed(()->{ result.setText("✓ OPTIMIZATION COMPLETE\n\nDevice information refreshed.\nAndroid settings remain under your control."); go.setEnabled(true); },1300);
        });
        Button game=btn("🎮  OPEN FREE FIRE",false); content.addView(game); game.setOnClickListener(v->launchGame());
        Button batteryBtn=btn("🔋  BATTERY SETTINGS",false); content.addView(batteryBtn); batteryBtn.setOnClickListener(v->openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
    }

    void showSettings(){
        clear();
        content.addView(tv("SETTINGS",25));
        content.addView(label("ANDROID SHORTCUTS"));
        Button d=btn("📺  DISPLAY SETTINGS",false); content.addView(d); d.setOnClickListener(v->openSettings(Settings.ACTION_DISPLAY_SETTINGS));
        Button b=btn("🔋  BATTERY SETTINGS",false); content.addView(b); b.setOnClickListener(v->openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        Button a=btn("ℹ️  APP INFO",false); content.addView(a); a.setOnClickListener(v->openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));
        Button u=btn("📊  USAGE ACCESS",false); content.addView(u); u.setOnClickListener(v->openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        content.addView(cardText("About\n\nSADEE × DIMA OPTIMIZER\nVersion 1.0\n\nDesigned for smooth Android gaming utilities on Android 15."));
    }

    void openSettings(String action){ openSettings(action,null); }
    void openSettings(String action, Uri data){
        try{ Intent i=new Intent(action); if(data!=null)i.setData(data); startActivity(i); }catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}
    }

    void launchGame(){
        String[] pkgs={"com.dts.freefireth","com.dts.freefiremax"};
        for(String p:pkgs){ Intent i=getPackageManager().getLaunchIntentForPackage(p); if(i!=null){startActivity(i);return;}}
        Toast.makeText(this,"Free Fire is not installed.",Toast.LENGTH_SHORT).show();
    }

    void startLive(){
        handler.post(new Runnable(){ public void run(){updateLive(); handler.postDelayed(this,1000);}});
    }

    void updateLive(){
        if(model!=null) model.setText("📱  PHONE MODEL\n"+Build.MANUFACTURER+" "+Build.MODEL);
        if(androidV!=null) androidV.setText("🤖  ANDROID\n"+Build.VERSION.RELEASE+"  •  API "+Build.VERSION.SDK_INT);
        ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
        long total=mi.totalMem, avail=mi.availMem, used=total-avail;
        if(ram!=null) ram.setText("🧠  RAM\n"+fmt(used)+" used  /  "+fmt(total)+" total\n"+fmt(avail)+" available");
        File f=Environment.getDataDirectory(); long totalS=f.getTotalSpace(), freeS=f.getFreeSpace(), usedS=totalS-freeS;
        if(storage!=null) storage.setText("💾  STORAGE\n"+fmt(usedS)+" used  /  "+fmt(totalS)+" total\n"+fmt(freeS)+" free");
        IntentFilter ift=new IntentFilter(Intent.ACTION_BATTERY_CHANGED); Intent bi=registerReceiver(null,ift);
        if(bi!=null){
            int level=bi.getIntExtra("level",0), scale=bi.getIntExtra("scale",100);
            int pct=(int)(level*100f/scale); int stat=bi.getIntExtra("status",-1);
            float tc=bi.getIntExtra("temperature",0)/10f;
            if(battery!=null)battery.setText("🔋  BATTERY\n"+pct+"%");
            if(temp!=null)temp.setText("🌡️  TEMPERATURE\n"+String.format(Locale.US,"%.1f°C",tc));
            String power=stat==2?"Charging":stat==5?"Full":"Not charging";
            if(charge!=null)charge.setText("⚡  POWER\n"+power);
        }
    }

    String fmt(long bytes){
        double n=bytes; String[] u={"B","KB","MB","GB","TB"}; int i=0;
        while(n>=1024 && i<u.length-1){n/=1024;i++;}
        return String.format(Locale.US,"%.1f %s",n,u[i]);
    }
}