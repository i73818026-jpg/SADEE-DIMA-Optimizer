package com.sadee.dima.optimizer

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OptimizerApp(this) }
    }
}

@Composable
fun OptimizerApp(context: Context) {
    var status by remember { mutableStateOf("Ready") }
    val battery = remember { getBatteryPercent(context) }
    val storage = remember { getStorageText() }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("SADEE × DIMA OPTIMIZER", style = MaterialTheme.typography.headlineSmall)
                Text("Free Android gaming utility", style = MaterialTheme.typography.bodyMedium)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Battery: $battery%")
                        Text("Storage: $storage")
                        Text("Status: $status")
                    }
                }
                Button(
                    onClick = { status = "Optimization checks completed safely." },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Optimize Now") }

                Button(
                    onClick = {
                        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
                        val launch = packages.firstNotNullOfOrNull { context.packageManager.getLaunchIntentForPackage(it) }
                        if (launch != null) context.startActivity(launch)
                        else status = "Free Fire is not installed."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Launch Free Fire") }

                OutlinedButton(
                    onClick = { context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Display Settings") }

                OutlinedButton(
                    onClick = { context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Battery Settings") }

                Spacer(Modifier.weight(1f))
                Text(
                    "This app does not modify game files, memory, packets, cheats, or anti-cheat systems.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

fun getBatteryPercent(context: Context): Int {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
}

fun getStorageText(): String {
    val stat = StatFs(android.os.Environment.getDataDirectory().path)
    val total = stat.totalBytes
    val free = stat.availableBytes
    val used = total - free
    fun gb(v: Long) = String.format(Locale.US, "%.1f GB", v / 1_073_741_824.0)
    return "${gb(used)} used / ${gb(total)} total"
}
